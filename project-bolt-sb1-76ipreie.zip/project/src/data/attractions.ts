import { Attraction } from '../types';

export const attractions: Attraction[] = [
  {
    id: '1',
    name: 'Senso-ji Temple',
    category: 'temples',
    location: 'Asakusa',
    description: 'Tokyo\'s oldest Buddhist temple, featuring the iconic Kaminarimon Gate.',
    estimatedDuration: 2,
    openingTime: '06:00',
    closingTime: '17:00',
    imageUrl: 'https://images.unsplash.com/photo-1545569341-9eb8b30979d9?auto=format&fit=crop&q=80&w=1000',
  },
  {
    id: '2',
    name: 'Tokyo National Museum',
    category: 'museums',
    location: 'Ueno',
    description: 'Japan\'s oldest and largest museum, housing priceless artifacts.',
    estimatedDuration: 3,
    openingTime: '09:30',
    closingTime: '17:00',
    imageUrl: 'https://images.unsplash.com/photo-1553292770-c3b6c3fb8346?auto=format&fit=crop&q=80&w=1000',
  },
  {
    id: '3',
    name: 'Shibuya Crossing',
    category: 'entertainment',
    location: 'Shibuya',
    description: 'The world\'s busiest pedestrian crossing.',
    estimatedDuration: 1,
    openingTime: '00:00',
    closingTime: '23:59',
    imageUrl: 'https://images.unsplash.com/photo-1542931287-023b922fa89b?auto=format&fit=crop&q=80&w=1000',
  },
  // Add more attractions as needed
];