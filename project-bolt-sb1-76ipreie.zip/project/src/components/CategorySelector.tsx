import React from 'react';
import { Check, MapPin } from 'lucide-react';
import { AttractionCategory } from '../types';

interface CategorySelectorProps {
  selectedCategories: AttractionCategory[];
  onCategoryToggle: (category: AttractionCategory) => void;
}

const categories: { id: AttractionCategory; label: string }[] = [
  { id: 'temples', label: 'Temples & Shrines' },
  { id: 'museums', label: 'Museums' },
  { id: 'shopping', label: 'Shopping' },
  { id: 'food', label: 'Food & Dining' },
  { id: 'parks', label: 'Parks & Nature' },
  { id: 'entertainment', label: 'Entertainment' },
];

export default function CategorySelector({ selectedCategories, onCategoryToggle }: CategorySelectorProps) {
  return (
    <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
      {categories.map((category) => (
        <button
          key={category.id}
          onClick={() => onCategoryToggle(category.id)}
          className={`p-4 rounded-lg border-2 transition-all ${
            selectedCategories.includes(category.id)
              ? 'border-blue-500 bg-blue-50'
              : 'border-gray-200 hover:border-gray-300'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="font-medium">{category.label}</span>
            {selectedCategories.includes(category.id) && (
              <Check className="w-5 h-5 text-blue-500" />
            )}
          </div>
        </button>
      ))}
    </div>
  );
}