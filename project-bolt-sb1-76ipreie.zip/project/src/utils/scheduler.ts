import { Attraction, AttractionCategory, DaySchedule, ScheduleItem } from '../types';

// Simulated traffic data - in a real app, this would come from an API
const getTrafficData = (time: string) => {
  const hour = parseInt(time.split(':')[0]);
  if (hour >= 7 && hour <= 9) return 'high';
  if (hour >= 17 && hour <= 19) return 'high';
  return 'low';
};

const addHoursToTime = (time: string, hours: number): string => {
  const [h, m] = time.split(':').map(Number);
  const newHours = h + Math.floor(hours);
  const minutes = m + (hours % 1) * 60;
  return `${String(newHours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}`;
};

export const generateSchedule = (
  attractions: Attraction[],
  selectedCategories: AttractionCategory[],
  startDate: string,
  days: number
): DaySchedule[] => {
  const schedule: DaySchedule[] = [];
  const filteredAttractions = attractions.filter(a => 
    selectedCategories.includes(a.category)
  );

  for (let i = 0; i < days; i++) {
    const date = new Date(startDate);
    date.setDate(date.getDate() + i);
    
    const daySchedule: DaySchedule = {
      date: date.toISOString().split('T')[0],
      items: [],
    };

    let currentTime = '09:00'; // Start day at 9 AM
    const availableAttractions = [...filteredAttractions];

    while (availableAttractions.length > 0 && currentTime < '21:00') {
      const traffic = getTrafficData(currentTime);
      
      // Find the best attraction based on current time and traffic
      const bestAttractionIndex = availableAttractions.findIndex(attraction => {
        const isOpen = currentTime >= attraction.openingTime && 
                      currentTime < attraction.closingTime;
        return isOpen;
      });

      if (bestAttractionIndex === -1) break;

      const attraction = availableAttractions[bestAttractionIndex];
      availableAttractions.splice(bestAttractionIndex, 1);

      // Add travel time based on traffic
      const travelTime = traffic === 'high' ? 1 : 0.5;
      currentTime = addHoursToTime(currentTime, travelTime);

      const scheduleItem: ScheduleItem = {
        ...attraction,
        startTime: currentTime,
        endTime: addHoursToTime(currentTime, attraction.estimatedDuration),
      };

      daySchedule.items.push(scheduleItem);
      currentTime = scheduleItem.endTime;
    }

    schedule.push(daySchedule);
  }

  return schedule;
};