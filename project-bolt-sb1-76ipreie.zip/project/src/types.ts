export interface Attraction {
  id: string;
  name: string;
  category: AttractionCategory;
  location: string;
  description: string;
  estimatedDuration: number; // in hours
  openingTime: string;
  closingTime: string;
  imageUrl: string;
}

export type AttractionCategory = 
  | 'temples'
  | 'museums'
  | 'shopping'
  | 'food'
  | 'parks'
  | 'entertainment';

export interface ScheduleItem extends Attraction {
  startTime: string;
  endTime: string;
}

export interface DaySchedule {
  date: string;
  items: ScheduleItem[];
}