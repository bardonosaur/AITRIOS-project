import React, { useState } from 'react';
import { Calendar } from 'lucide-react';
import { AttractionCategory, DaySchedule } from './types';
import { attractions } from './data/attractions';
import { generateSchedule } from './utils/scheduler';
import CategorySelector from './components/CategorySelector';
import Schedule from './components/Schedule';

function App() {
  const [selectedCategories, setSelectedCategories] = useState<AttractionCategory[]>([]);
  const [startDate, setStartDate] = useState(
    new Date().toISOString().split('T')[0]
  );
  const [days, setDays] = useState(3);
  const [schedule, setSchedule] = useState<DaySchedule[]>([]);

  const handleCategoryToggle = (category: AttractionCategory) => {
    setSelectedCategories(prev =>
      prev.includes(category)
        ? prev.filter(c => c !== category)
        : [...prev, category]
    );
  };

  const handleGenerateSchedule = () => {
    if (selectedCategories.length === 0) return;
    const newSchedule = generateSchedule(
      attractions,
      selectedCategories,
      startDate,
      days
    );
    setSchedule(newSchedule);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-4xl mx-auto p-6">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Tokyo Trip Planner
          </h1>
          <p className="text-gray-600">
            Select your interests and get an optimized schedule for your Tokyo adventure
          </p>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          <h2 className="text-xl font-semibold mb-4">What would you like to see?</h2>
          <CategorySelector
            selectedCategories={selectedCategories}
            onCategoryToggle={handleCategoryToggle}
          />

          <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Start Date
              </label>
              <input
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Number of Days
              </label>
              <input
                type="number"
                min="1"
                max="7"
                value={days}
                onChange={(e) => setDays(parseInt(e.target.value))}
                className="w-full px-3 py-2 border border-gray-300 rounded-md"
              />
            </div>
          </div>

          <button
            onClick={handleGenerateSchedule}
            disabled={selectedCategories.length === 0}
            className="mt-6 w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 disabled:bg-gray-400 disabled:cursor-not-allowed flex items-center justify-center gap-2"
          >
            <Calendar className="w-5 h-5" />
            Generate Schedule
          </button>
        </div>

        <Schedule schedule={schedule} />
      </div>
    </div>
  );
}

export default App;