import React, { useState, useEffect } from 'react';
import { RefreshCw } from 'lucide-react';
import { AttractionCategory, Attraction } from './types';
import { attractions } from './data/attractions';
import { fetchCrowdData, getRecommendedAttractions } from './utils/crowdSensor';
import CategorySelector from './components/CategorySelector';
import AttractionCard from './components/AttractionCard';
import DeveloperPanel from './components/DeveloperPanel';

function App() {
  const [selectedCategories, setSelectedCategories] = useState<AttractionCategory[]>([]);
  const [updatedAttractions, setUpdatedAttractions] = useState<Attraction[]>(attractions);
  const [isLoading, setIsLoading] = useState(false);
  const [lastUpdate, setLastUpdate] = useState<Date | null>(null);

  const handleCategoryToggle = (category: AttractionCategory) => {
    setSelectedCategories(prev =>
      prev.includes(category)
        ? prev.filter(c => c !== category)
        : [...prev, category]
    );
  };

  const updateCrowdData = async () => {
    setIsLoading(true);
    try {
      const updatedData = await Promise.all(
        updatedAttractions.map(async (attraction) => {
          if (!attraction.sensorId) return attraction;
          const crowdData = await fetchCrowdData(attraction.location);
          return {
            ...attraction,
            currentCount: crowdData?.count,
          };
        })
      );
      setUpdatedAttractions(updatedData);
      setLastUpdate(new Date());
    } catch (error) {
      console.error('Failed to update crowd data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    updateCrowdData();
    const interval = setInterval(updateCrowdData, 300000); // Update every 5 minutes
    return () => clearInterval(interval);
  }, []);

  const handleUpdateSensor = (attractionId: string, sensorId: string | undefined) => {
    setUpdatedAttractions(prev =>
      prev.map(attraction =>
        attraction.id === attractionId
          ? { ...attraction, sensorId }
          : attraction
      )
    );
  };

  const recommendedAttractions = getRecommendedAttractions(
    updatedAttractions,
    selectedCategories
  );

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-6xl mx-auto p-6">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Smart Tokyo Trip Planner
          </h1>
          <p className="text-gray-600">
            Find the best times to visit Tokyo's attractions using real-time crowd data
          </p>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold">What would you like to see?</h2>
            <button
              onClick={updateCrowdData}
              disabled={isLoading}
              className="flex items-center gap-2 text-sm text-blue-600 hover:text-blue-700"
            >
              <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
              Refresh Data
            </button>
          </div>
          
          <CategorySelector
            selectedCategories={selectedCategories}
            onCategoryToggle={handleCategoryToggle}
          />

          {lastUpdate && (
            <p className="text-sm text-gray-500 mt-4">
              Last updated: {lastUpdate.toLocaleTimeString()}
            </p>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {recommendedAttractions.map((attraction) => (
            <AttractionCard
              key={attraction.id}
              attraction={attraction}
            />
          ))}
        </div>

        {selectedCategories.length > 0 && recommendedAttractions.length === 0 && (
          <div className="text-center py-8 text-gray-600">
            No recommended attractions found for the selected categories at this time.
            Try selecting different categories or check back later.
          </div>
        )}

        <DeveloperPanel
          attractions={updatedAttractions}
          onUpdateSensor={handleUpdateSensor}
        />
      </div>
    </div>
  );
}

export default App;