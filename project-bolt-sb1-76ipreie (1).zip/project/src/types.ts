export interface Attraction {
  id: string;
  name: string;
  category: AttractionCategory;
  location: string;
  description: string;
  imageUrl: string;
  expectedCapacity: number;
  currentCount?: number;
  sensorId?: string;
}

export type AttractionCategory = 
  | 'temples'
  | 'museums'
  | 'shopping'
  | 'food'
  | 'parks'
  | 'entertainment';

export interface CrowdData {
  count: number;
  timestamp: string;
  occupancyRatio: number;
}

export interface Sensor {
  id: string;
  name: string;
  status: 'active' | 'inactive';
  lastPing?: string;
}