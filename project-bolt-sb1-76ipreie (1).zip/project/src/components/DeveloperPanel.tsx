import React, { useState } from 'react';
import { Settings, AlertCircle } from 'lucide-react';
import { Attraction, Sensor } from '../types';

interface DeveloperPanelProps {
  attractions: Attraction[];
  onUpdateSensor: (attractionId: string, sensorId: string | undefined) => void;
}

// Simulated available sensors
const availableSensors: Sensor[] = [
  { id: 'sensor-1', name: 'AITRIOS-001', status: 'active', lastPing: new Date().toISOString() },
  { id: 'sensor-2', name: 'AITRIOS-002', status: 'active', lastPing: new Date().toISOString() },
  { id: 'sensor-3', name: 'AITRIOS-003', status: 'inactive' },
];

export default function DeveloperPanel({ attractions, onUpdateSensor }: DeveloperPanelProps) {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="relative">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="fixed bottom-4 right-4 bg-gray-900 text-white p-3 rounded-full shadow-lg hover:bg-gray-800 transition-colors"
        title="Developer Settings"
      >
        <Settings className="w-6 h-6" />
      </button>

      {isOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg shadow-xl w-full max-w-3xl">
            <div className="flex items-center justify-between p-4 border-b">
              <h2 className="text-xl font-semibold">Sensor Management</h2>
              <button
                onClick={() => setIsOpen(false)}
                className="text-gray-500 hover:text-gray-700"
              >
                ✕
              </button>
            </div>

            <div className="p-4">
              <div className="mb-4">
                <h3 className="text-lg font-medium mb-2">Available Sensors</h3>
                <div className="grid grid-cols-3 gap-2 mb-4">
                  {availableSensors.map(sensor => (
                    <div
                      key={sensor.id}
                      className={`p-3 rounded-lg border ${
                        sensor.status === 'active' 
                          ? 'border-green-200 bg-green-50' 
                          : 'border-red-200 bg-red-50'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <div className={`w-2 h-2 rounded-full ${
                          sensor.status === 'active' ? 'bg-green-500' : 'bg-red-500'
                        }`} />
                        <span className="font-medium">{sensor.name}</span>
                      </div>
                      {sensor.lastPing && (
                        <p className="text-xs text-gray-500 mt-1">
                          Last ping: {new Date(sensor.lastPing).toLocaleTimeString()}
                        </p>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <h3 className="text-lg font-medium mb-2">Attraction Assignments</h3>
                <div className="space-y-3">
                  {attractions.map(attraction => (
                    <div
                      key={attraction.id}
                      className="flex items-center justify-between p-3 border rounded-lg"
                    >
                      <div>
                        <h4 className="font-medium">{attraction.name}</h4>
                        <p className="text-sm text-gray-500">{attraction.location}</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <select
                          value={attraction.sensorId || ''}
                          onChange={(e) => onUpdateSensor(attraction.id, e.target.value || undefined)}
                          className="border rounded px-3 py-1"
                        >
                          <option value="">No Sensor</option>
                          {availableSensors
                            .filter(s => s.status === 'active')
                            .map(sensor => (
                              <option
                                key={sensor.id}
                                value={sensor.id}
                                disabled={attractions.some(
                                  a => a.sensorId === sensor.id && a.id !== attraction.id
                                )}
                              >
                                {sensor.name}
                              </option>
                            ))}
                        </select>
                        {!attraction.sensorId && (
                          <AlertCircle className="w-5 h-5 text-yellow-500" title="No sensor assigned" />
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="border-t p-4 bg-gray-50 rounded-b-lg">
              <p className="text-sm text-gray-600">
                Note: Changes to sensor assignments may take up to 5 minutes to reflect in the crowd data.
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}