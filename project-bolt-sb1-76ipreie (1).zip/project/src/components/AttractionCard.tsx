import React from 'react';
import { MapPin, Users } from 'lucide-react';
import { Attraction } from '../types';

interface AttractionCardProps {
  attraction: Attraction;
}

export default function AttractionCard({ attraction }: AttractionCardProps) {
  const occupancyRatio = attraction.currentCount 
    ? (attraction.currentCount / attraction.expectedCapacity)
    : null;

  const getOccupancyColor = (ratio: number) => {
    if (ratio < 0.5) return 'text-green-600 bg-green-50';
    if (ratio < 0.8) return 'text-yellow-600 bg-yellow-50';
    return 'text-red-600 bg-red-50';
  };

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden">
      <img
        src={attraction.imageUrl}
        alt={attraction.name}
        className="w-full h-48 object-cover"
      />
      <div className="p-4">
        <h3 className="text-xl font-semibold mb-2">{attraction.name}</h3>
        <p className="text-gray-600 text-sm mb-4">{attraction.description}</p>
        
        <div className="flex items-center gap-4 text-sm">
          <div className="flex items-center gap-1 text-gray-500">
            <MapPin className="w-4 h-4" />
            <span>{attraction.location}</span>
          </div>
          
          {occupancyRatio !== null && (
            <div className={`flex items-center gap-1 px-2 py-1 rounded-full ${getOccupancyColor(occupancyRatio)}`}>
              <Users className="w-4 h-4" />
              <span>{Math.round(occupancyRatio * 100)}% Full</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}