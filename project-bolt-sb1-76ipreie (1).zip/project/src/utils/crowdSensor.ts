import { Attraction, CrowdData } from '../types';

const API_BASE_URL = 'https://aitrios-usitinker-260203.s3-website-us-east-1.amazonaws.com/api';

export async function fetchCrowdData(location: string): Promise<CrowdData | null> {
  try {
    const response = await fetch(`${API_BASE_URL}/crowd_count?location=${encodeURIComponent(location)}`);
    if (!response.ok) throw new Error('Failed to fetch crowd data');
    
    const data = await response.json();
    return {
      count: parseInt(data.count),
      timestamp: new Date().toISOString(),
      occupancyRatio: 0, // Will be calculated later
    };
  } catch (error) {
    console.error('Error fetching crowd data:', error);
    return null;
  }
}

export function calculateOccupancyRatio(currentCount: number, expectedCapacity: number): number {
  return currentCount / expectedCapacity;
}

export function getRecommendedAttractions(
  attractions: Attraction[],
  selectedCategories: string[]
): Attraction[] {
  return attractions
    .filter(attraction => 
      selectedCategories.includes(attraction.category) &&
      attraction.currentCount !== undefined &&
      (attraction.currentCount / attraction.expectedCapacity) < 0.8
    )
    .sort((a, b) => {
      const ratioA = (a.currentCount || 0) / a.expectedCapacity;
      const ratioB = (b.currentCount || 0) / b.expectedCapacity;
      return ratioA - ratioB;
    });
}