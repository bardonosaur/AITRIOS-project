import { Attraction } from '../types';

export const attractions: Attraction[] = [
  {
    id: '1',
    name: 'Senso-ji Temple',
    category: 'temples',
    location: 'Asakusa',
    description: 'Tokyo\'s oldest Buddhist temple, featuring the iconic Kaminarimon Gate.',
    expectedCapacity: 2000,
    imageUrl: 'https://images.unsplash.com/photo-1545569341-9eb8b30979d9?auto=format&fit=crop&q=80&w=1000',
  },
  {
    id: '2',
    name: 'Tokyo National Museum',
    category: 'museums',
    location: 'Ueno',
    description: 'Japan\'s oldest and largest museum, housing priceless artifacts.',
    expectedCapacity: 1500,
    imageUrl: 'https://images.unsplash.com/photo-1553292770-c3b6c3fb8346?auto=format&fit=crop&q=80&w=1000',
  },
  {
    id: '3',
    name: 'Shibuya Crossing',
    category: 'entertainment',
    location: 'Shibuya',
    description: 'The world\'s busiest pedestrian crossing.',
    expectedCapacity: 3000,
    imageUrl: 'https://images.unsplash.com/photo-1542931287-023b922fa89b?auto=format&fit=crop&q=80&w=1000',
  },
];